function Item(name, sell_in, quality) {
  //do not alter this
  this.name = name;
  this.sell_in = sell_in;
  this.quality = quality;
}

function GildedRose() {
  var items = [];
  items.push(new Item("+5 Dexterity Vest", 10, 20));
  items.push(new Item("Elixir of the Mongoose", 5, 7));
  items.push(new Item("Aged Brie", 2, 0));
  items.push(new Item("Backstage passes to a TAFKAL80ETC concert", 15, 20));
  items.push(new Item("Backstage passes to a TAFKAL80ETC concert", 10, 49));
  items.push(new Item("Backstage passes to a TAFKAL80ETC concert", 5, 4));
  items.push(new Item("Sulfuras, Hand of Ragnaros", 0, 80));
  items.push(new Item("Sulfuras, Hand of Ragnaros", -1, 80));
  items.push(new Item("Conjured Mana Cake", 3, 6));
}
//start update_quality
//Code discussion will be over refactoring and cleaning up the code with the below functions
GildedRose.update_quality = function(items) {
  for (var i = 0; i < items.length; i++) {
    //This conditional looks at all other items not named aged brie and backstage passes
    //and decreases quality by 1 point
    //Aged brie and backstage passes increase in quality as it's sell-in day appraoches
    //Backstage passes drop to 0 quality concert
    //Brie increases by 1 quality point everyday
    if (this.regularItems(items[i]) && items[i].quality > 0) {
      items[i].quality = items[i].quality - 1;
    }
    //item quality is never more than 50
    else if (this.canIncreaseQuality(items[i])) {
      items[i].quality = items[i].quality + 1;
      //if item name is Backstage passes, quality increases by 1 eveyr day
      if (items[i].name == "Backstage passes to a TAFKAL80ETC concert") {
        //if sell in day is 10 days or less quality increases by 2
        if (items[i].sell_in < 11) {
          if (this.canIncreaseQuality(items[i])) {
            //why isn't this plus 2?
            items[i].quality = items[i].quality + 1;
          }
        }
        if (items[i].sell_in < 6) {
          //if sell in day is 5 days or less quality increases by 3
          if (this.canIncreaseQuality(items[i])) {
            //why isn't this plus 3?
            items[i].quality = items[i].quality + 1;
          }
        }
      }
    }

    //if item isn't Sulfuras then it has to be sold
    //all other items items has their sell in date subtracted
    if (this.decreaseAfterSellIn(items[i])) {
      this.decreaseSellIn(items[i]);
    }
    //once the sell in date has passed
    if (items[i].sell_in < 0) {
      //if item isn't name Aged Brie
      if (items[i].name != "Aged Brie") {
        //item isn't named Backstage passes
        if (items[i].name != "Backstage passes to a TAFKAL80ETC concert") {
          //if item quality is more than 0 or not named Sulfuras(never sold or decreases in quality)
          //this conditional for sulfuras is repeated
          if (items[i].quality > 0) {
            if (this.decreaseAfterSellIn(items[i])) {
              //decreases item quality daily
              items[i].quality = items[i].quality - 1;
            }
          }
          //end repeat
        }
        //item quality degrades twice as fast after sell by date?
        else {
          items[i].quality = items[i].quality - items[i].quality;
        }
      } else if (this.canIncreaseQuality(items[i])) {
        items[i].quality = items[i].quality + 1;
      }
    }
    //added
    if (this.conjured(items[i])) {
      items[i].quality = items[i].quality - 1;
    }
  }
  return items;
};
//end update_quality

//takes all items that aren't considered legendary
GildedRose.regularItems = function(items) {
  return (
    items.name != "Aged Brie" &&
    items.name != "Backstage passes to a TAFKAL80ETC concert" &&
    items.name != "Sulfuras, Hand of Ragnaros"
  );
};
//for items that only increase in quality
GildedRose.increaseQuality = function(items) {
  this.canIncreaseQuality(items);
  if (
    (items.name == "Aged Brie" ||
      items.name == "Backstage passes to a TAFKAL80ETC concert") &&
    items.sell_in < 11
  ) {
    this.canIncreaseQuality(items);
    if (items.sell_in < 6) {
      this.canIncreaseQualitys(items);
    }
  }
};
//checks in item quality is 50
GildedRose.canIncreaseQuality = function(items) {
  return items.quality < 50;
};
//decreases sell_in date for everything except Sulfuras
GildedRose.decreaseSellIn = function(items) {
  if (items.name != "Sulfuras, Hand of Ragnaros") {
    items.sell_in--;
  }
};
//if an item is conjured or expired, the quality =decreases twice as fast
GildedRose.decreaseQualityTwiceAsFast = function(items) {
  if (items.name == this.conjured || this.expired) {
    return items.quality - 2;
  }
};
//looks for conjured item
GildedRose.conjured = function(items) {
  return items.name == "Conjured Mana Cake";
};
//an item is expired if it's sell_in is zero or less than
GildedRose.expired = function(items) {
  return items.sell_in <= 0;
};
